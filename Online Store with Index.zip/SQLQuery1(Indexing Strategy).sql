
/*3*/



CREATE UNIQUE INDEX idx_users_email ON Users(Email);
GO
----------------------------------------------------
CREATE INDEX idx_products_name ON Products(Name);
GO

CREATE INDEX idx_products_price ON Products(Price);
GO
--------------------------------------------------------

CREATE INDEX idx_orders_date ON Orders(OrderDate);
GO

CREATE INDEX idx_orders_status ON Orders(OrderStatus);
GO
---------------------------------------------------------

CREATE INDEX idx_orders_date ON Orders(OrderDate);
GO

CREATE INDEX idx_orders_status ON Orders(OrderStatus);
GO
------------------------------------------------------------

CREATE INDEX idx_orderdetails_order_product ON OrderDetails(OrderID, ProductID);
GO
-------------------------------------------------------------------

CREATE INDEX idx_payments_status ON Payments(PaymentStatus) WHERE PaymentStatus = 'Confirmed';
GO

------------------------------------------------------------------------
SELECT * FROM sys.dm_db_index_usage_stats WHERE object_id = OBJECT_ID('Orders');
GO

--------------------------------------------------------------------------

SELECT name, type_desc
FROM sys.indexes
WHERE object_id = OBJECT_ID('Orders');
GO

-------------------------------------------------


SELECT COLUMN_NAME
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'dm_db_index_usage_stats';
GO

SELECT name, type_desc
FROM sys.indexes
WHERE object_id = OBJECT_ID('Orders');
GO






