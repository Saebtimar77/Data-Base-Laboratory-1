CREATE DATABASE OnlineStore;
GO

USE OnlineStore;

CREATE TABLE Users (
    UserID INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(100) NOT NULL,
    Email NVARCHAR(255) UNIQUE NOT NULL,
    Password NVARCHAR(255) NOT NULL,
    Address NVARCHAR(255),
    PhoneNumber NVARCHAR(20),
    CreatedAt DATETIME DEFAULT GETDATE()
);
GO

CREATE TABLE Products (
    ProductID INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(100) NOT NULL,
    Description NVARCHAR(255),
    Price DECIMAL(10,2) NOT NULL CHECK (Price >= 0),
    StockQuantity INT NOT NULL,
    CategoryID INT
);
GO

CREATE TABLE Categories (
    CategoryID INT PRIMARY KEY IDENTITY(1,1),
    CategoryName NVARCHAR(100) NOT NULL,
    ParentCategoryID INT NULL
);
GO

CREATE TABLE Orders (
    OrderID INT PRIMARY KEY IDENTITY(1,1),
    UserID INT NOT NULL,
    TotalAmount DECIMAL(10,2) NOT NULL,
    OrderStatus NVARCHAR(50) DEFAULT 'Processing',
    OrderDate DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);
GO

CREATE TABLE OrderDetails (
    OrderDetailID INT PRIMARY KEY IDENTITY(1,1),
    OrderID INT NOT NULL,
    ProductID INT NOT NULL,
    Quantity INT NOT NULL CHECK (Quantity > 0),
    Price DECIMAL(10,2) NOT NULL CHECK (Price >= 0),
    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID),
    FOREIGN KEY (ProductID) REFERENCES Products(ProductID)
);
GO


CREATE TABLE Payments (
    PaymentID INT PRIMARY KEY IDENTITY(1,1),
    OrderID INT NOT NULL,
    PaymentMethod NVARCHAR(50) NOT NULL,
    PaymentStatus NVARCHAR(50) NOT NULL DEFAULT 'Pending',
    TransactionID NVARCHAR(100),
    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID)
);
GO

CREATE TABLE Shipping (
    ShippingID INT PRIMARY KEY IDENTITY(1,1),
    OrderID INT NOT NULL,
    ShippingAddress NVARCHAR(255) NOT NULL,
    ShippingMethod NVARCHAR(50) NOT NULL,
    TrackingNumber NVARCHAR(100),
    EstimatedDeliveryDate DATETIME,
    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID)
);
GO

CREATE INDEX idx_users_email ON Users(Email);
GO

CREATE INDEX idx_products_name ON Products(Name);
GO

CREATE INDEX idx_orders_date ON Orders(OrderDate);
GO

CREATE PROCEDURE AddOrder
    @UserID INT,
    @TotalAmount DECIMAL(10,2),
    @OrderStatus NVARCHAR(50)
AS
BEGIN
    INSERT INTO Orders (UserID, TotalAmount, OrderStatus, OrderDate)
    VALUES (@UserID, @TotalAmount, @OrderStatus, GETDATE());

    SELECT SCOPE_IDENTITY() AS NewOrderID;
END;
GO

CREATE TRIGGER trg_UpdateOrderDate
ON Orders
AFTER UPDATE
AS
BEGIN
    UPDATE Orders
    SET OrderDate = GETDATE()
    WHERE OrderID IN (SELECT DISTINCT OrderID FROM inserted);
END;
GO

CREATE VIEW OrderSummary AS
SELECT o.OrderID, u.Name AS CustomerName, o.TotalAmount, o.OrderStatus, o.OrderDate
FROM Orders o
JOIN Users u ON o.UserID = u.UserID;
GO

SELECT * FROM Users;
SELECT * FROM Products;
SELECT * FROM Orders;
SELECT * FROM OrderSummary;
GO









